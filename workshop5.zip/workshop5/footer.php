   <hr>
   <footer>&copy: Herald college kathmandu</footer>
</body>
</html>