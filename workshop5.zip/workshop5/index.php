<?php include "header.php" ?>
<ul>

<li><a href="addstudent.php">Add Student</a></li>
<li><a href="students.php">view Student</a></li>
<li><a href="upload.php">upload file</a></li>


</ul>
<?php include "footer.php"?>